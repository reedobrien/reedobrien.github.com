## goredirect

redirects requests based on json configuration